In this directory you will find precompiled binaries of LibXML2 v 2.6.10 for PocketPC ARM platforms

The library was compiled in release mode PocketPC/ARM platforms, WITHOUT THREADING SUPPORT AND WITHOUT ICONV SUPPORT

It is recommended NOT to use this libraries if you have the opportunity to compile libxml2 yourself. 

These binaries are provided as a help for people wishing to build the GPAC SVG reader for windowsCE/ARM platforms. They may not work or 
even damage your device, use at your own risks.

For more instruction on how to compile the SVG plugin for GPAC, please refer to GPAC Install documentation

