void CPU_64_on();
void CPU_64_off();

void CPU_64_on(){

__asm(	".set noreorder;"
	    "mfc0	$4,$12;"
		"li		$5,-1;"
		"sll	$5,$5,1;"
		"and	$4,$4,$5;"
		"mtc0	$4,$12;"
		"nop;"
		".set reorder;"
		);

}
 
void CPU_64_off(){

__asm(	".set noreorder;"
	    " mfc0	$4,$12;"
		" nop;"
		" nop;"
		" ori	$4,$4,0x001;"
		" mtc0	$4,$12;"
		" nop;"
		".set reorder;"
		);
}

void MIPS_edge_copy(char *p_border_top,char *p_border_top_ref,int width){
	__asm ("srl	$8,$6,4;"
			"bucle: ldr	$10,0($5);"
			"ldr	$11,8($5);"
			".set noreorder;"
			"cache	13,0($4);"
			".set reorder;"
			"addi	$5,$5,16;"
			"sdr	$10,0($4);"
			"sdr	$11,8($4);"
			"addi	$8,$8,-1;"
			"addi	$4,$4,16;"
			"bgtz	$8,bucle;"
			"andi	$6,$6,0x08;"
			"beq	$6,$0,final;"
			"ldr	$10,0($5);"
			"sdr	$10,0($4);"
			"final:"
			);
}
void MIPS_MEM_SET(char *p_border_top,int p_border_top_ref,int width){
	__asm ("srl	$8,$6,4;"
			"dsll	$10,$5,56;"
			"dsrl	$11,$10,8;"
			"or		$10,$10,$11;"
			"dsrl	$11,$10,16;"
			"or		$10,$10,$11;"
			"dsrl	$11,$10,32;"
			"or		$10,$10,$11;"
			"bucle2:.set noreorder;"
			"cache	13,0($4);"
			".set reorder;"
			"sdr	$10,0($4);"
			"sdr	$10,8($4);"
			"addi	$8,$8,-1;"
			"addi	$4,$4,16;"
			"bgtz	$8,bucle2;"
			);
}