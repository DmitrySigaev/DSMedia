/********************************************************************************
 *																				*
 * This code has been developed by Project Mayo. This software is an			*
 * implementation of a part of one or more MPEG-4 Video tools as				*
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this			*
 * software module in hardware or software products are advised that its		*
 * use may infringe existing patents or copyrights, and any such use			*
 * would be at such party's own risk.  The original developer of this			*
 * software module and his/her company, and subsequent editors and their		*
 * companies (including Project Mayo), will have no liability for use of		*
 * this software or modifications or derivatives thereof.						*
 *																				*
 ********************************************************************************
 *																				*	
 * This program is free software; you can redistribute it and/or modify			*
 * it under the terms of the GNU General Public License as published by			*
 * the Free Software Foundation; either version 2 of the License, or			*
 * (at your option) any later version.											*
 *																				*
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html				*
 *																				*
 * Authors:																		*
 *																				*
 *	Andrea Graziani	(Ag):														*
 *		- Original source code (Open Divx Decoder 0.4a).						*		
 *																				*
 *	Pedro Mateu		(Pm):														*
 *		- Heavily modified and optimized code + MIPS ASM						*
 *																				*
 *  'MindPower'																	*
 *		- ARM ASM routines.														*
 *																				*
 ********************************************************************************/


#include "global.h"

// this routine now in CopyBlock.obj (asm)
// Purpose: specialized basic motion compensation routines

#ifdef MIPS_ASM_64

static void CopyBlock(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm(	"addi	$2,$0,+8;" 
"bucle	:uld	$10,0($4);" 
		"add	$2,$2,-1;" 
		"add	$4,$4,$6;"
		"sdr	$10,0($5);" 
		"add	$5,$5,$6;" 
		"bgtz	$2,bucle;"); 

} 
 

static void CopyBlockHor(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm (	"addi	$2,$0,+8;" 
		
	   // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

"bucle2	:uld	$9,0($4);" 
		"uld	$10,1($4);" 
		
		"or		$14,$9,$10;"
		"and	$14,$14,$24;"
		
		"add	$4,$4,$6;" 
		"addi	$2,$2,-1;" 
	
		"and	$9,$9,$25;" 
		"and	$10,$10,$25;" 
	
		"dsrl	$9,$9,1;"   //divide by 2
		"dsrl	$10,$10,1;" 

		"daddu	$9,$9,$10;"
		"daddu	$10,$9,$14;"
		"sdr	$10,0($5);"	
			
		"add	$5,$5,$6;" 

		"bgtz	$2,bucle2;");

} 

static void CopyBlockVer(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm (	"addi	$2,$0,+8;" 
		  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

		//first point preprocessing
		
		"uld	$9,0($4);"	

		"move	$13,$9;"

		"and	$9,$9,$25;" 
		"dsrl	$9,$9,1;"

"bucle3 :add	$4,$4,$6;" 
		
		"uld	$10,0($4);" 
				
		"addi	$2,$2,-1;" 

		"or		$14,$13,$10;"
		"and	$14,$14,$24;"

		// in order to divide by two 
			
		"and	$10,$10,$25;" 
		
		//divide by two
		
		"dsrl	$10,$10,1;" 
		
		"daddu	$9,$9,$10;" 
		"daddu	$9,$9,$14;"	//we add 1
		"sdr	$9,0($5);"
		
		"move	$9,$10;"
		
		"add	$5,$5,$6;" 

		"bgtz	$2,bucle3;");  

} 

static void CopyBlockHorVer(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm (	"addi	$2,$0,+8;" 
		  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

		//first line preprocessing
		
		"uld	$10,0($4);" 
		"uld	$11,1($4);"
		
		"or		$14,$11,$10;"
		"and	$14,$14,$24;"
		
		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 
		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 
		"daddu	$10,$10,$11;"
		"daddu	$10,$10,$14;"
		"move	$15,$10;"
		"and	$10,$10,$25;" 
		"dsrl	$10,$10,1;" 

"bucle4 :addu	$4,$4,$6;"
	
		"uld	$12,0($4);" 
		"uld	$13,1($4);"

		"or		$14,$13,$12;"
		"and	$14,$14,$24;"
		
		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
		
		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"
		
		"daddu	$12,$12,$13;"
		"daddu	$12,$12,$14;"

		"or		$14,$15,$12;"
		"and	$14,$14,$24;"

		"and	$12,$12,$25;" 
		
		"dsrl	$12,$12,1;" 

		"daddu	$10,$10,$12;"
		"daddu	$10,$10,$14;"//add 1
		"sdr	$10,0($5);"
		
		"move	$10,$12;"

		"addi	$2,$2,-1;" 
		"add	$5,$5,$6;" 

		"bgtz	$2,bucle4;");  

} 

static void CopyBlockHorRound(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm (	"addi	$2,$0,+8;" 
				  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

		
"bucle5	:uld	$10,0($4);" 
		"uld	$11,1($4);"
		
		"and	$14,$11,$10;"
	    "and	$14,$14,$24;"

		"addi	$2,$2,-1;" 
		"add	$4,$4,$6;" 

		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 

		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 

		"daddu	$10,$10,$11;" 
		"daddu	$10,$10,$14;" 
		"sdr	$10,0($5);"
		
		"add	$5,$5,$6;" 

		"bgtz	$2,bucle5;"); 


} 

static void CopyBlockVerRound(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 
__asm (	"addi	$2,$0,+8;" 
		
			  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"


		"uld	$10,0($4);"
		
		"move	$14,$10;"
	    		
		"and	$10,$10,$25;" 	
		"dsrl	$10,$10,1;" 

"bucle6	:add	$4,$4,$6;"
		"uld	$11,0($4);" 
		
		"and	$14,$11,$10;"
	    "and	$14,$14,$24;"
		
		"add	$3,$3,$6;" 
		
		"and	$11,$11,$25;" 

		"dsrl	$11,$11,1;" 

		"daddu	$10,$10,$11;" 
		"daddu	$10,$10,$14;" 
		"sdr	$10,0($5);"

		"move	$10,$11;"
		
		"addi	$2,$2,-1;" 
		"add	$5,$5,$6;" 

"bgtz	$2,bucle6;"); 
} 

static void CopyBlockHorVerRound(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm (	"addi	$2,$0,+8;" 

	  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

		//line preprocessing

		"uld	$10,0($4);" 
		"uld	$11,1($4);"

		"and	$14,$10,$11;" 
		"and	$14,$14,$24;" 
		
		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 

		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 

		"daddu	$10,$10,$11;"
		"daddu	$10,$10,$14;"
		"move	$15,$10;"
		
		"and	$10,$10,$25;" 

		"dsrl	$10,$10,1;"

"bucle7 :add	$4,$4,$6;" 
		"uld	$12,0($4);" 
		"uld	$13,1($4);"
				
		"and	$14,$12,$13;" 
		"and	$14,$14,$24;" 
		
		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
	
		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"

		"daddu	$12,$12,$13;"
		"daddu	$12,$12,$14;"
		
		"and	$14,$12,$15;" 
		"and	$14,$14,$24;" 

		"and	$12,$12,$25;" 
	
		"dsrl	$12,$12,1;" 

		"daddu	$10,$10,$12;"
		"daddu	$10,$10,$14;"
		"sdr	$10,0($5);"
		
		"move	$10,$12;"

		"addi	$2,$2,-1;" 
		"add	$5,$5,$6;" 

"bgtz	$2,bucle7;");  
}

static void CopyMBlock(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 
__asm(	"addi	$2,$0,+16;" 
"bucle8	:uld	$24,0($4);" 
		"uld	$25,8($4);" 
	
		"add	$2,$2,-1;" 
		"add	$4,$4,$6;" 
		
		".set noreorder;"
		"cache	13,0($5);"
		".set reorder;"
		
		"sdr	$24,0($5);" 
		"sdr	$25,8($5);" 
		"add	$5,$5,$6;" 
"bgtz	$2,bucle8;"); 
} 

static void CopyMBlockHor(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 
__asm(	"addi	$2,$0,+16;"
		
		  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

"bucle9	:uld	$10,0($4);" 
		"uld	$11,8($4);" 
		"uld	$12,1($4);"
		"uld	$13,9($4);"
		
		"or		$14,$10,$12;" 
		"and	$14,$14,$24;" 
		"or		$15,$11,$13;"
		"and	$15,$15,$24;"
		
		"addi	$2,$2,-1;" 
		"add	$4,$4,$6;" 

		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 
		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
		
		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 
		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"
		
		".set noreorder;"
		"cache	13,0($5);"
		".set reorder;"


		"daddu	$10,$10,$12;"
		"daddu	$11,$11,$13;"

		"daddu	$10,$10,$14;"	//we add 1
		"sdr	$10,0($5);"	
		"daddu	$10,$11,$15;"
		"sdr	$10,8($5);"
		"add	$5,$5,$6;" 

"bgtz $2,bucle9;");
} 

static void CopyMBlockVer(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 
__asm(	"addi	$2,$0,+16;"

	  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

		//line preprocessing
		
		"uld	$10,0($4);" 
		"uld	$11,8($4);"
	
		"move	$7,$10;" 
		"move	$3,$11;" 

		"or		$15,$11,$13;"
		"and	$15,$15,$24;"

		
		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 
		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 
		
"bucle10:add	$4,$4,$6;" 
		"uld	$12,0($4);"
		"uld	$13,8($4);"
		
		"or		$14,$7,$12;" 
		"and	$14,$14,$24;" 
		"or		$15,$3,$13;"
		"and	$15,$15,$24;"
		
		"addi	$2,$2,-1;" 
				
		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
		
		".set noreorder;"
		"cache	13,0($5);"
		".set reorder;"

		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"

		"daddu	$10,$10,$12;"
		"daddu	$10,$10,$14;"	//we add 1
		"sdr	$10,0($5);"
		"move	$10,$12;"
		
		"daddu	$11,$11,$13;"
		"daddu	$11,$11,$15;"
		"sdr	$11,8($5);"
		"move	$11,$13;"

		"add	$5,$5,$6;" 

"bgtz $2,bucle10;");
} 

static void CopyMBlockHorRound(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

	__asm(	"addi	$2,$0,+16;"
		
		  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

"bucle12:uld	$10,0($4);" 
		"uld	$11,8($4);" 
		"uld	$12,1($4);"
		"uld	$13,9($4);"
		
		"and	$14,$10,$12;" 
		"and	$14,$14,$24;" 
		"and	$15,$11,$13;"
		"and	$15,$15,$24;"
		
		"addi	$2,$2,-1;" 
		"add	$4,$4,$6;" 

		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 
		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
		
		".set noreorder;"
		"cache	13,0($5);"
		".set reorder;"

		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 
		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"
		
		"daddu	$10,$10,$12;" 
		"daddu	$10,$10,$14;" 
		"sdr	$10,0($5);"
		"daddu	$10,$11,$13;"
		"daddu	$10,$10,$15;" 
		"sdr	$10,8($5);"
		
		"add	$5,$5,$6;" 

"bgtz $2,bucle12;");
} 

static void CopyMBlockVerRound(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 
__asm(	"addi	$2,$0,+16;"
		
		  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"
	
		"uld	$10,0($4);" 
		"uld	$11,8($4);"	
		
		"move	$7,$10;" 
		"move	$3,$14;" 
			
		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 
		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;"

"bucle13:add	$4,$4,$6;" 
		"uld	$12,0($4);"
		"uld	$13,8($4);"
		
		"and	$14,$7,$12;" 
		"and	$14,$14,$24;" 
		"and	$15,$3,$13;"
		"and	$15,$15,$24;"

		"addi	$2,$2,-1;" 
				
		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
	
		".set noreorder;"
		"cache	13,0($5);"
		".set reorder;"


		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"
		
		"daddu	$10,$10,$12;" 
		"daddu	$10,$10,$14;" 
		"sdr	$10,0($5);"
		"move	$10,$12;"

		"daddu	$11,$11,$13;"
		"daddu	$11,$11,$15;"
		"sdr	$11,8($5);"
		"move	$11,$13;"
		
		"add	$5,$5,$6;" 


"bgtz $2,bucle13;");
} 

static void CopyMBlockHorVer(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm (	"addi	$2,$0,+16;" 
	  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

		//first line preprocessing
		
		"uld	$7,0($4);" 
		"uld	$9,1($4);"
		"uld	$10,8($4);" 
		"uld	$11,9($4);"

		"and	$7,$7,$25;" 
		"and	$9,$9,$25;" 
		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 

		"dsrl	$7,$7,1;" 
		"dsrl	$9,$9,1;" 
		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 

		"daddu	$7,$7,$9;"
		"daddu	$10,$10,$11;"

		"and	$7,$7,$25;"
		"and	$10,$10,$25;" 

		"dsrl	$7,$7,1;"
		"dsrl	$10,$10,1;" 

"bucle14:addu	$4,$4,$6;"
	
		"uld	$12,0($4);" 
		"uld	$13,1($4);"
		"uld	$14,8($4);" 
		"uld	$15,9($4);"

		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
		"and	$14,$14,$25;"
		"and	$15,$15,$25;"

		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"
		"dsrl	$14,$14,1;"
		"dsrl	$15,$15,1;"

		".set noreorder;"
		"cache	13,0($5);"
		".set reorder;"

		"daddu	$12,$12,$13;"
		"daddu	$14,$14,$15;"	

		"and	$12,$12,$25;" 
		"and	$14,$14,$25;" 

		"dsrl	$12,$12,1;" 
		"dsrl	$14,$14,1;"

		"daddu	$7,$7,$12;"
		"daddu	$7,$7,$24;"//add 1
		"sdr	$7,0($5);"
		"move	$7,$12;"

		"daddu	$10,$10,$14;"
		"daddu	$10,$10,$24;"//add 1
		"sdr	$10,8($5);"
		"move	$10,$14;"

		"addi	$2,$2,-1;" 
		"add	$5,$5,$6;" 

"bgtz	$2,bucle14;");  

} 

static void CopyMBlockHorVerRound(unsigned char * Src, unsigned char * Dst, int Stride) 
{ 

__asm (	"addi	$2,$0,+16;" 

	  // 0x0101 0101 0101 0101

		"li		$24,0x01010101;"
		"dsll	$24,$24,32;"
		"dsrl	$10,$24,32;"
		"or		$24,$24,$10;"

		// 0xFEFE FEFE FEFE FEFE

		"nor	$25,$24,$0;"

		//line preprocessing

		"uld	$7,0($4);" 
		"uld	$9,1($4);"
		"uld	$10,8($4);" 
		"uld	$11,9($4);"

		"and	$7,$7,$25;" 
		"and	$9,$9,$25;" 
		"and	$10,$10,$25;" 
		"and	$11,$11,$25;" 

		"dsrl	$7,$7,1;" 
		"dsrl	$9,$9,1;"
		"dsrl	$10,$10,1;" 
		"dsrl	$11,$11,1;" 

		"daddu	$7,$7,$9;"
		"daddu	$7,$7,$24;"
		"daddu	$10,$10,$11;"
		"daddu	$10,$10,$24;"
	
		"and	$7,$7,$25;" 
		"and	$10,$10,$25;" 

		"dsrl	$7,$7,1;"
		"dsrl	$10,$10,1;"

"bucle15:add	$4,$4,$6;" 
		"uld	$12,0($4);" 
		"uld	$13,1($4);"
		"uld	$14,8($4);" 
		"uld	$15,9($4);"
		
		"and	$12,$12,$25;"
		"and	$13,$13,$25;"
		"and	$14,$14,$25;"
		"and	$15,$15,$25;"

		"dsrl	$12,$12,1;"
		"dsrl	$13,$13,1;"
		"dsrl	$14,$14,1;"
		"dsrl	$15,$15,1;"

		"daddu	$12,$12,$13;"
		"daddu	$12,$12,$24;"
		"daddu	$14,$14,$15;"
		"daddu	$14,$14,$24;"
		
		"and	$12,$12,$25;" 
		"and	$14,$14,$25;"

		".set noreorder;"
		"cache	13,0($5);"
		".set reorder;"

		"dsrl	$12,$12,1;" 
		"dsrl	$14,$14,1;"

		"daddu	$7,$7,$12;"
		"sdr	$7,0($5);"
		"move	$7,$12;"

		"daddu	$10,$10,$14;"
		"sdr	$10,8($5);"
		"move	$10,$14;"

		"addi	$2,$2,-1;" 
		"add	$5,$5,$6;" 

"bgtz	$2,bucle15;");  

  }


#else
#define _ALIGNEDLOAD(a)  ((Src[a]>>Right_Shift)|(Src[a+1]<<Left_Shift))
/*
void CopyBlock(unsigned int *Src, unsigned int *Dst, int Stride)
{
	int dy;
	int Right_Shift;
	int Left_Shift;
	Right_Shift=((unsigned int)Src)&3;
	Stride>>=2;
	if (!Right_Shift)
	{
		for (dy = 0; dy < 8; dy++) 
		{
			Dst[0] = Src[0];
			Dst[1] = Src[1];
		
			Dst += Stride;
			Src += Stride;
		}
	}
	else
	{
		Left_Shift=4-Right_Shift;
		Right_Shift<<=3;
		Left_Shift<<=3;
		Src= (unsigned int*)(((unsigned int)Src)&0xFFFFFFFC);
		for (dy = 0; dy < 8; dy++) 
		{
			Dst[0] = _ALIGNEDLOAD(0) ;
			Dst[1] = _ALIGNEDLOAD(1) ;
		
			Dst += Stride;
			Src += Stride;
		}
	}
}

void CopyMBlock(unsigned int * Src, unsigned int * Dst, int Stride)
{
	int dy, Right_Shift, Left_Shift;
	Right_Shift=((unsigned int)Src)&3;
	Stride>>=2;
	if (!Right_Shift)
	{
		for (dy = 0; dy < 16; dy++) 
		{
			Dst[0] = Src[0];
			Dst[1] = Src[1];
			Dst[2] = Src[2];
			Dst[3] = Src[3];

			Dst += Stride;
			Src += Stride;
		}
	}
	else
	{
		Left_Shift=4-Right_Shift;
		Right_Shift<<=3;
		Left_Shift<<=3;
		Src= (unsigned int*)(((unsigned int)Src)&0xFFFFFFFC);
		for (dy = 0; dy < 16; dy++) 
		{
			Dst[0] = _ALIGNEDLOAD(0);
			Dst[1] = _ALIGNEDLOAD(1);
			Dst[2] = _ALIGNEDLOAD(2);
			Dst[3] = _ALIGNEDLOAD(3);
		
			Dst += Stride;
			Src += Stride;
		}
	}
} 
void CopyBlockHorVerRound(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;
	unsigned char * D=Dst;
	unsigned char * S=Src;
	int last;
	for (dx = 0; dx <8; dx++) {
		S=Src;
		D=Dst;
		last=S[dx] + S[dx+1];
		for (dy = 0; dy < 8; dy++) {
			int next=S[dx+Stride] + S[dx+Stride+1];
			D[dx] = (last + next+1) >> 2; // horver interpolation with rounding
			last=next;
			S += Stride;
			D += Stride;
		}
	}
}
*/
#ifndef ARM_ASM
void CopyBlock(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy;
	for (dy = 0; dy < 8; dy++) 
	{
		Dst[0] = Src[0];
		Dst[1] = Src[1];
		Dst[2] = Src[2];
		Dst[3] = Src[3];
		Dst[4] = Src[4];
		Dst[5] = Src[5];
		Dst[6] = Src[6];
		Dst[7] = Src[7];

		Dst += Stride;
		Src += Stride;
	}
}

/**/
void CopyBlockHor(unsigned char * Src,unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 8; dy != 0; dy--) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]+1) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void CopyBlockVer(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 8; dy != 0; dy--) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride] +1) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void CopyBlockHorVer(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 8; dy != 0; dy--) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] + 
								Src[dx+Stride] + Src[dx+Stride+1] +2) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void CopyBlockHorRound(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 8; dy != 0; dy--) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void CopyBlockVerRound(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 8; dy != 0; dy--) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride]) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
void CopyBlockHorVerRound(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 8; dy != 0; dy--) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] + 
								Src[dx+Stride] + Src[dx+Stride+1] +1) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}

/**/
/** *** **/
// this routine now in CopyMBlock.obj (asm)
void CopyMBlock(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy;

	for (dy = 0; dy < 16; dy++) {
		Dst[0] = Src[0];
		Dst[1] = Src[1];
		Dst[2] = Src[2];
		Dst[3] = Src[3];
		Dst[4] = Src[4];
		Dst[5] = Src[5];
		Dst[6] = Src[6];
		Dst[7] = Src[7];
		Dst[8] = Src[8];
		Dst[9] = Src[9];
		Dst[10] = Src[10];
		Dst[11] = Src[11];
		Dst[12] = Src[12];
		Dst[13] = Src[13];
		Dst[14] = Src[14];
		Dst[15] = Src[15];

		Dst += Stride;
		Src += Stride;
	}
} 
/**/
void CopyMBlockHor(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 16; dy != 0; dy--) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]+1) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void CopyMBlockVer(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 16; dy != 0; dy--) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride] +1) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}

void CopyMBlockHorRound(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 16; dy != 0; dy--) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void CopyMBlockVerRound(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 16; dy != 0; dy--) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride]) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
void CopyMBlockHorVer(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 16; dy != 0; dy--) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] + 
								Src[dx+Stride] + Src[dx+Stride+1] +2) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
void CopyMBlockHorVerRound(unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 16; dy != 0; dy--) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] + 
								Src[dx+Stride] + Src[dx+Stride+1] +1) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
#endif
#endif


/**/

static void recon_comp (unsigned char *src, unsigned char *dst, int lx, int w, int x, int y, int dx, int dy);

/**/

void reconstruct (int x, int y, int mode)
{
	int dx, dy;
	unsigned char comp;
	unsigned short px, py;
	int acc_x=0,acc_y=0;
		
	// Luma
	
	px = x << 4;
	py = y << 4;
	if (mode == INTER4V)
	{
		for (comp = 0; comp < 4; comp++)
		{
			dx = MV[x][comp];
			dy = dx>>16;
			dx = (dx<<16)>>16;
			
			acc_x+=dx;
			acc_y+=dy;

			recon_comp (frame_for[0], frame_ref[0], mp4_hdr.coded_picture_width, 8, px + ((comp & 1) << 3), py + ((comp & 2) << 2), dx, dy);
		}
	} else
	{
		dx = MV[x][0];
		dy = dx>>16;
		dx = (dx<<16)>>16;

		recon_comp (frame_for[0], frame_ref[0], mp4_hdr.coded_picture_width, 16, px, py, dx, dy);
	}

	// Chr
	px = x << 3;
	py = y << 3;
	if (mode == INTER4V)
	{
		if (acc_x == 0) dx = 0;
		else
			dx = sign (acc_x) * (roundtab[abs (acc_x) & 0xF] + ((abs (acc_x) >> 4) <<1));
		
		if (acc_y == 0)	dy = 0;
		else
			dy = sign (acc_y) * (roundtab[abs (acc_y) & 0xF] + ((abs (acc_y) >> 4) <<1));
	} else
	{
		// chroma rounding 
		dx = ((dx & 0x3) == 0 ? dx >> 1 : (dx >> 1) | 1);
		dy = ((dy & 0x3) == 0 ? dy >> 1 : (dy >> 1) | 1);
	}

	recon_comp (frame_for[1], frame_ref[1], mp4_hdr.coded_picture_width>>1, 8, px, py, dx, dy);
	recon_comp (frame_for[2], frame_ref[2], mp4_hdr.coded_picture_width>>1, 8, px, py, dx, dy);
}

/**/
int total;
static void recon_comp (unsigned char *src, unsigned char *dst, 
                        int lx, int w, int x, 
                        int y, int dx, int dy)
{
	unsigned char *s, *d;
	int mc_driver;
	//int t=GetTickCount();
	// origins 
	s = src + lx * (y + (dy >> 1)) + x + (dx >> 1);
	d = dst + lx * y + x;

	mc_driver = ((w!=8)<<3) | (mp4_hdr.rounding_type<<2) | ((dy & 1)<<1) | (dx & 1);

	switch (mc_driver)
		{
			// block
			// no round
			case 0: case 4:
 				CopyBlock(s, d, lx);
				break;
			case 1:
				CopyBlockHor(s, d, lx);
				break;
			case 2:
				CopyBlockVer(s, d, lx);
				break;
			case 3:
				CopyBlockHorVer(s, d, lx);
				break;
				// round
			case 5:
				CopyBlockHorRound(s, d, lx);
				break;
			case 6:
				CopyBlockVerRound(s, d, lx);
				break;
			case 7:
				CopyBlockHorVerRound(s, d, lx);
				break;
		// macroblock
			// no round
			case 8: case 12:
				CopyMBlock(s, d, lx);
				break;
			case 9:
				CopyMBlockHor(s, d, lx);
				break;
			case 10:
				CopyMBlockVer(s, d, lx);
				break;
			case 11:
				CopyMBlockHorVer(s, d, lx);
				break;
			// round
			case 13:
				CopyMBlockHorRound(s, d, lx);
				return;
			case 14:
				CopyMBlockVerRound(s, d, lx);
				break;
			default : //15
				CopyMBlockHorVerRound(s, d, lx);
				break;
		}
		//total+=GetTickCount()-t;
}
