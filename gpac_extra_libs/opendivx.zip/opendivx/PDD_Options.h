/********************************************************************************
 *																				*	
 * This program is free software; you can redistribute it and/or modify			*
 * it under the terms of the GNU General Public License as published by			*
 * the Free Software Foundation; either version 2 of the License, or			*
 * (at your option) any later version.											*
 *																				*
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html				*
 *																				*
 * Author:																		*
 *																				*
 *	Pedro Mateu		(Pm)														*
 *																				*				
 ********************************************************************************/

//
//	Current Decoder options
//

#define PocketPC

#ifdef MIPS
	#define MIPS_VR41XX		//Most used processor.
#endif

//
//	Maximun picture size options:
//
//	Max_X_Size -> Maximun x size in pixels.*
//	Max_Y_Size -> Maximun y size in pixels.*
//
//	* For the best perfomance, a size = 2^x is required. IE:256,512,1024... 
//

#ifdef PocketPC
	#define Max_X_Size 512
	#define Max_Y_Size 512
#elif defined DreamCast
	#define Max_X_Size 1024
	#define Max_Y_Size 512
#else 
	#error No maximun picture size selected.
#endif

#define MB_X_Size ((Max_X_Size+15)>>4)
#define MB_Y_Size ((Max_Y_Size+15)>>4)
	
//
//	Processor optimizations switches
//

#ifdef MIPS

	#ifdef MIPS_VR41XX			// VR series can handle all MIPS optimizations	

		#define MIPS_ASM		//	Enable MIPS32 ASM
		#define MIPS_ASM_64		//	Enable MIPS64 ASM and low level cache instructions.
		#define MIPS_ASM_MACC	//	Enable fast Multiply and Accumulate Unit.

	#elif defined MIPS_PHILIPS	//	IE: NINO series.

		#define MIPS_ASM

	#else 
		
		#error No processor selected

	#endif

#endif

#ifdef ARM

	#define ARM_VARS			//	Use ints instead of signed shorts
	#define ARM_ASM				//	Enable ARM V4 ASM.

#endif