/********************************************************************************
 *																				*
 * This code has been developed by Project Mayo. This software is an			*
 * implementation of a part of one or more MPEG-4 Video tools as				*
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this			*
 * software module in hardware or software products are advised that its		*
 * use may infringe existing patents or copyrights, and any such use			*
 * would be at such party's own risk.  The original developer of this			*
 * software module and his/her company, and subsequent editors and their		*
 * companies (including Project Mayo), will have no liability for use of		*
 * this software or modifications or derivatives thereof.						*
 *																				*
 ********************************************************************************
 *																				*	
 * This program is free software; you can redistribute it and/or modify			*
 * it under the terms of the GNU General Public License as published by			*
 * the Free Software Foundation; either version 2 of the License, or			*
 * (at your option) any later version.											*
 *																				*
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html				*
 *																				*
 * Authors:																		*
 *																				*
 *	Andrea Graziani	(Ag):														*
 *		- Original source code (Open Divx Decoder 0.4a).						*		
 *																				*
 *	Pedro Mateu		(Pm):														*
 *		- Modified code.														*
 *																				*
 ********************************************************************************/

// global.h //

/* GLOBAL is defined in only one file */

#include "portab.h"
#include "PDD_Options.h"
#include "mp4_header.h"
#include <stdlib.h>
#ifndef GLOBAL
#define EXTERN extern
#else
#define EXTERN
#endif

//
//	macros 
//

#define mmax(a, b)        ((a) > (b) ? (a) : (b))
#define mmin(a, b)        ((a) < (b) ? (a) : (b))
#define sign(a)			  ((a) < 0 ? -1 : 1)

// 
// 	prototypes of global functions
//

// getbits.c 

void initbits (unsigned char *stream);
unsigned int showbits (int n);
void flushbits (int n);
unsigned int getbits (int n);
unsigned int getbits1 (void);

// 
//		global variables 
//

// zig-zag scan

const unsigned char zig_zag_scan[64]
#ifdef GLOBAL
=
{
  0, 1, 8, 16, 9, 2, 3, 10, 17,
  24, 32, 25, 18, 11, 4, 5, 12, 
  19, 26, 33, 40, 48, 41, 34, 27,
  20, 13, 6, 7, 14, 21, 28, 35, 42,
  49, 56, 57, 50, 43, 36, 29, 22,
  15, 23, 30, 37, 44, 51, 58, 59, 
  52, 45, 38, 31, 39, 46, 53, 60, 61,
  54, 47, 55, 62, 63
}
#endif
;

// other scan orders
const unsigned char alternate_horizontal_scan[64]
#ifdef GLOBAL
=
{
   0,  1,  2,  3,  8,  9, 16, 17, 
	10, 11,  4,  5,  6,  7, 15, 14,
  13, 12, 19, 18, 24, 25, 32, 33, 
	26, 27, 20, 21, 22, 23, 28, 29,
  30, 31, 34, 35, 40, 41, 48, 49, 
	42, 43, 36, 37, 38, 39, 44, 45,
  46, 47, 50, 51, 56, 57, 58, 59, 
	52, 53, 54, 55, 60, 61, 62, 63
}
#endif
;

const unsigned char alternate_vertical_scan[64]
#ifdef GLOBAL
=
{
   0,  8, 16, 24,  1,  9,  2, 10, 
	17, 25, 32, 40, 48, 56, 57, 49,
  41, 33, 26, 18,  3, 11,  4, 12, 
	19, 27, 34, 42, 50, 58, 35, 43,
  51, 59, 20, 28,  5, 13,  6, 14, 
	21, 29, 36, 44, 52, 60, 37, 45,
  53, 61, 22, 30,  7, 15, 23, 31, 
	38, 46, 54, 62, 39, 47, 55, 63
}
#endif
;

const unsigned char roundtab[16]
#ifdef GLOBAL
= {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2}
#endif
;

//#define roundtab(x) (0xA5555540>>(x<<1))

//
//	mp4 stuff
//


EXTERN mp4_header mp4_hdr;

EXTERN int MV[MB_X_Size][4];  
EXTERN char modemap[MB_X_Size*MB_Y_Size];

EXTERN struct _base
{
 	// DCT BLOCK
	int bitcnt;
	unsigned char *rdptr;
#ifdef MIPS_ASM_64
	int stride;
	int stride2;
#endif

	idct_block_t block[64];
	
	// DATA BUFFER
	
} ld;

EXTERN struct _ac_dc
{

	// DC_LUM format: [mb_xpos][mb_ypos]
	
	idct_block_t dc_lum[2*MB_X_Size][4];
	
	// AC_LUM format: [mb_xpos][value]
	
	idct_block_t ac_left_lum[2][8];
	idct_block_t ac_top_lum[2*MB_X_Size][8]; 
	
	// DC_CHR format: [U/V][mb_xpos][mb_ypos]

	idct_block_t dc_chr[2][MB_X_Size][2];

	// AC_CHR format: [U/V][mb_xpos][left/top][value]

	idct_block_t ac_left_chr[2][8];
	idct_block_t ac_top_chr[MB_X_Size][2][8];

	int predict_dir;

} coeff_pred;
EXTERN unsigned char * frame_ref[3],*frame_for[3];
EXTERN unsigned char * tempBB;
