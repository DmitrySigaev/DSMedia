
void IDCT_S (idct_block_t *Block, uint8_t *DestU8, int Stride, unsigned char Mode);
static void IDCT_Row_S (idct_block_t *Blk,uint8_t *DestU8, unsigned char Mode);
static void IDCT_Col (idct_block_t *Blk);

#define W1 2841                 // 2048*sqrt(2)*cos(1*pi/16) 
#define W2 2676                 // 2048*sqrt(2)*cos(2*pi/16) 
#define W3 2408                 // 2048*sqrt(2)*cos(3*pi/16) 
#define W5 1609                 // 2048*sqrt(2)*cos(5*pi/16) 
#define W6 1108                 // 2048*sqrt(2)*cos(6*pi/16) 
#define W7 565                  // 2048*sqrt(2)*cos(7*pi/16) 

#define W1_minus_W7 2276
#define W1_plus_W7 3406
#define W3_minus_W5 799
#define W3_plus_W5 4017
#define W2_minus_W6 1568
#define W2_plus_W6 3784