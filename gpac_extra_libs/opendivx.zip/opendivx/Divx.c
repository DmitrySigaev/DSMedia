/********************************************************************************
 *																				*
 * This code has been developed by Project Mayo. This software is an			*
 * implementation of a part of one or more MPEG-4 Video tools as				*
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this			*
 * software module in hardware or software products are advised that its		*
 * use may infringe existing patents or copyrights, and any such use			*
 * would be at such party's own risk.  The original developer of this			*
 * software module and his/her company, and subsequent editors and their		*
 * companies (including Project Mayo), will have no liability for use of		*
 * this software or modifications or derivatives thereof.						*
 *																				*
 ********************************************************************************
 *																				*	
 * This program is free software; you can redistribute it and/or modify			*
 * it under the terms of the GNU General Public License as published by			*
 * the Free Software Foundation; either version 2 of the License, or			*
 * (at your option) any later version.											*
 *																				*
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html				*
 *																				*
 ********************************************************************************
 *																				*
 *	This source is the PocketMVP Divx Decoder. It�s a heavily modified and		 	*	
 *	optimized version of Project Mayo�s Open Divx Decoder 0.4a. This code has	*
 *	been designed and developed in order to get a fast decoder for PocketPC�s   *
 *	RICS processors.															*		
 *																				*
 *	Authors:																	*
 *																				*
 *		Marc Dukette	(Md)													*
 *		Pedro Mateu		(Pm)													*
 *																				*
 *	PocketMVP Divx Decoder v0.61													*
 *																				*	
 ********************************************************************************/
 
#include "global.h"
#include "decore.h"

/**/
extern int LastDropped;
int decore_init(int hor_size, int ver_size, unsigned long color_depth, int output_format);
int decore_release();
//void decore_frame(unsigned char *stream, int length, unsigned char *bmp, int render_flag, int Extra);
//int decore_setoutput(unsigned long color_depth, int output_format);

/**/

static int flag_firstpicture = 1;

/**/

int DecodeInit(unsigned long handle, unsigned long dec_opt,
	void *param1, void *param2)
{
	switch (dec_opt)
	{
		case DEC_OPT_INIT:
			{DEC_PARAM *dec_param = (DEC_PARAM *) param1;
			
 			int x_size = dec_param->x_dim;
 			int y_size = dec_param->y_dim;
			unsigned long color_depth = dec_param->color_depth;
			int output_format = dec_param->output_format;
			decore_init(x_size, y_size, color_depth, output_format); // init decoder resources

			return DEC_OK;
			}
			break; 
		case DEC_OPT_RELEASE:
			decore_release();
			return DEC_OK;
			break;
		default:
			return DEC_OK;
			break;
	}
}

/**/
int header=0;
extern int total;

int decore_init(int hor_size, int ver_size, unsigned long color_depth, int output_format)
{
	// init global stuff
	// read first vol and vop
	header=0;
	LastDropped=0;
	total=0;
	mp4_hdr.width = hor_size;
	mp4_hdr.height = ver_size;
	mp4_hdr.quant_precision = 5;
	if (flag_firstpicture == 1) {
		mp4_hdr.time_increment_resolution = 0;
		flag_firstpicture = 0;
	}
    mp4_hdr.mb_xsize = ( mp4_hdr.width + 15 ) / 16; 
	mp4_hdr.mb_ysize = ( mp4_hdr.height + 15 ) / 16;
	mp4_hdr.mba_size = mp4_hdr.mb_xsize * mp4_hdr.mb_ysize;

	// set picture dimension global vars
	
	mp4_hdr.coded_picture_width = ((mp4_hdr.width+15)&0xFFF0) + 64;
	mp4_hdr.coded_picture_height =((mp4_hdr.height+15)&0xFFF0) + 64;
	
	initdecoder();
	return 1;
}
/**/
int DecodeFrame(unsigned char *stream, int length, unsigned char *bmp, int render_flag)
{
	initbits (stream);
	getvolhdr();
	if (!getvophdr()) return 0; // read vop header
	Decode_MPEG4_Picture(bmp, render_flag); // decode vop
	LastDropped=!render_flag;
	return 1;
}

/**/

int decore_release()
{
	closedecoder();
	return 1;
}
