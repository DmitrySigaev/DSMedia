/**************************************************************************
 *                                                                        *
 * This code has been developed by Andrea Graziani. This software is an   *
 * implementation of a part of one or more MPEG-4 Video tools as          *
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this    *
 * software module in hardware or software products are advised that its  *
 * use may infringe existing patents or copyrights, and any such use      *
 * would be at such party's own risk.  The original developer of this     *
 * software module and his/her company, and subsequent editors and their  *
 * companies (including Project Mayo), will have no liability for use of  *
 * this software or modifications or derivatives thereof.                 *
 *                                                                        *
 /***************************************************************************************
 *This program is free software; you can redistribute it and/or modify					*
 * it under the terms of the GNU General Public License as published by					*
 * the Free Software Foundation; either version 2 of the License, or					*
 * (at your option) any later version.													*
 *																						*
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html						*
 *																						*
 *																						*	
 ****************************************************************************************/
/**************************************************************************
 *																		  *
 * Copyright (C) 2001 - Project Mayo									  *	
 *																		  *
 * Andrea Graziani (Ag)													  *	
 *																		  *	
 * DivX Advanced Research Center <darc@projectmayo.com>					  *
 *																	      *		
 **************************************************************************/

// mp4_mblock.h //

#ifndef _MP4_MBLOCK_H_
#define _MP4_MBLOCK_H_

/**/

const char DQtab[4] = {
	-1, -2, 1, 2
};

const unsigned char MCBPCtabIntra[] = {
	0,0, //-1,0
	20,6, 36,6, 52,6, 4,4, 4,4, 4,4, 
	4,4, 19,3, 19,3, 19,3, 19,3, 19,3, 
	19,3, 19,3, 19,3, 35,3, 35,3, 35,3, 
	35,3, 35,3, 35,3, 35,3, 35,3, 51,3, 
	51,3, 51,3, 51,3, 51,3, 51,3, 51,3, 
	51,3
};

const unsigned char MCBPCtabInter[] = {
	0,0, //-1,0
	0,9, 52,9, 36,9, 20,9, 49,9, 35,8, 35,8, 19,8, 19,8,
	50,8, 50,8, 51,7, 51,7, 51,7, 51,7, 34,7, 34,7, 34,7,
	34,7, 18,7, 18,7, 18,7, 18,7, 33,7, 33,7, 33,7, 33,7, 
	17,7, 17,7, 17,7, 17,7, 4,6, 4,6, 4,6, 4,6, 4,6, 
	4,6, 4,6, 4,6, 48,6, 48,6, 48,6, 48,6, 48,6, 48,6, 
	48,6, 48,6, 3,5, 3,5, 3,5, 3,5, 3,5, 3,5, 3,5, 
	3,5, 3,5, 3,5, 3,5, 3,5, 3,5, 3,5, 3,5, 3,5, 
	32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 
	32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 
	32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 32,4, 
	32,4, 32,4, 32,4, 32,4, 32,4, 16,4, 16,4, 16,4, 16,4, 
	16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 
	16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 
	16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 16,4, 
	16,4, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 
	2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 
	2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 
	2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 
	2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 
	2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 
	2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 2,3, 
	2,3, 2,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 
	1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 
	1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 
	1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 
	1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 
	1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 
	1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 1,3, 
	1,3, 1,3, 1,3
};

/**/

const unsigned char CBPYtab[] = 
{ 
	0,0, 0,0, 6,6,  9,6,  8,5,  8,5,  4,5,  4,5,//-1,0
	2,5,  2,5,  1,5,  1,5,  0,4,  0,4,  0,4,  0,4, 
	12,4, 12,4, 12,4, 12,4, 10,4, 10,4, 10,4, 10,4,
	14,4, 14,4, 14,4, 14,4, 5,4,  5,4,  5,4,  5,4,
	13,4, 13,4, 13,4, 13,4, 3,4,  3,4,  3,4,  3,4, 
	11,4, 11,4, 11,4, 11,4, 7,4,  7,4,  7,4,  7,4 
};

#endif // _MP4_MBLOCK_H_

/**/


