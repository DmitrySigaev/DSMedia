/**************************************************************************
 *                                                                        *
 * This code has been developed by Andrea Graziani. This software is an   *
 * implementation of a part of one or more MPEG-4 Video tools as          *
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this    *
 * software module in hardware or software products are advised that its  *
 * use may infringe existing patents or copyrights, and any such use      *
 * would be at such party's own risk.  The original developer of this     *
 * software module and his/her company, and subsequent editors and their  *
 * companies (including Project Mayo), will have no liability for use of  *
 * this software or modifications or derivatives thereof.                 *
 *                                                                        *
 /***************************************************************************************
 *This program is free software; you can redistribute it and/or modify					*
 * it under the terms of the GNU General Public License as published by					*
 * the Free Software Foundation; either version 2 of the License, or					*
 * (at your option) any later version.													*
 *																						*
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html						*
 *																						*
 *																						*	
 ****************************************************************************************/
/**************************************************************************
 *																		  *
 * Copyright (C) 2001 - Project Mayo									  *	
 *																		  *
 * Andrea Graziani (Ag)													  *	
 *																		  *	
 * DivX Advanced Research Center <darc@projectmayo.com>					  *
 *																	      *		
 **************************************************************************/

const char MVtab0[] =
{
	3,4, -3,4, 2,3, 2,3, -2,3, -2,3, 1,2, 1,2, 1,2, 1,2,
	-1,2, -1,2, -1,2, -1,2
};

const char MVtab1[] = 
{
	12,10, -12,10, 11,10, -11,10, 10,9, 10,9, -10,9, -10,9,
	9,9, 9,9, -9,9, -9,9, 8,9, 8,9, -8,9, -8,9, 7,7, 7,7,
	7,7, 7,7, 7,7, 7,7, 7,7, 7,7, -7,7, -7,7, -7,7, -7,7,
	-7,7, -7,7, -7,7, -7,7, 6,7, 6,7, 6,7, 6,7, 6,7, 6,7,
	6,7, 6,7, -6,7, -6,7, -6,7, -6,7, -6,7, -6,7, -6,7,
	-6,7, 5,7, 5,7, 5,7, 5,7, 5,7, 5,7, 5,7, 5,7, -5,7,
	-5,7, -5,7, -5,7, -5,7, -5,7, -5,7, -5,7, 4,6, 4,6, 4,6,
	4,6, 4,6, 4,6, 4,6, 4,6, 4,6, 4,6, 4,6, 4,6, 4,6, 4,6,
	4,6, 4,6, -4,6, -4,6, -4,6, -4,6, -4,6, -4,6, -4,6,
	-4,6, -4,6, -4,6, -4,6, -4,6, -4,6, -4,6, -4,6, -4,6
};

const char MVtab2[] = 
{
	32,12, -32,12, 31,12, -31,12, 30,11, 30,11, -30,11, -30,11,
	29,11, 29,11, -29,11, -29,11, 28,11, 28,11, -28,11, -28,11,
	27,11, 27,11, -27,11, -27,11, 26,11, 26,11, -26,11, -26,11,
	25,11, 25,11, -25,11, -25,11, 24,10, 24,10, 24,10, 24,10,
	-24,10, -24,10, -24,10, -24,10, 23,10, 23,10, 23,10, 23,10,
	-23,10, -23,10, -23,10, -23,10, 22,10, 22,10, 22,10, 22,10,
	-22,10, -22,10, -22,10, -22,10, 21,10, 21,10, 21,10, 21,10,
	-21,10, -21,10, -21,10, -21,10, 20,10, 20,10, 20,10, 20,10,
	-20,10, -20,10, -20,10, -20,10, 19,10, 19,10, 19,10, 19,10,
	-19,10, -19,10, -19,10, -19,10, 18,10, 18,10, 18,10, 18,10,
	-18,10, -18,10, -18,10, -18,10, 17,10, 17,10, 17,10, 17,10,
	-17,10, -17,10, -17,10, -17,10, 16,10, 16,10, 16,10, 16,10,
	-16,10, -16,10, -16,10, -16,10, 15,10, 15,10, 15,10, 15,10,
	-15,10, -15,10, -15,10, -15,10, 14,10, 14,10, 14,10, 14,10,
	-14,10, -14,10, -14,10, -14,10, 13,10, 13,10, 13,10, 13,10,
	-13,10, -13,10, -13,10, -13,10
};

