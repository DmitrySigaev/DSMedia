/**************************************************************************
 *                                                                        *
 * This code has been developed by Andrea Graziani. This software is an   *
 * implementation of a part of one or more MPEG-4 Video tools as          *
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this    *
 * software module in hardware or software products are advised that its  *
 * use may infringe existing patents or copyrights, and any such use      *
 * would be at such party's own risk.  The original developer of this     *
 * software module and his/her company, and subsequent editors and their  *
 * companies (including Project Mayo), will have no liability for use of  *
 * this software or modifications or derivatives thereof.                 *
 *                                                                        *
 *                                                                        *
 /***************************************************************************************
 *This program is free software; you can redistribute it and/or modify					*
 * it under the terms of the GNU General Public License as published by					*
 * the Free Software Foundation; either version 2 of the License, or					*
 * (at your option) any later version.													*
 *																						*
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html						*
 *																						*
 *																						*	
 ****************************************************************************************/
/**************************************************************************
 *                                                                        *  
 * Copyright (C) 2001 - Project Mayo                                      *
 *                                                                        *    
 * Andrea Graziani (Ag)                                                   *  
 *                                                                        *   
 * DivX Advanced Research Center <darc@projectmayo.com>                   *
 **************************************************************************/

#include "global.h"


void initdecoder ();
void closedecoder ();
void initdecoder ()
{
	int i, size_lum,size_crom;
    unsigned char * BigBuff=tempBB= malloc(mp4_hdr.coded_picture_width * mp4_hdr.coded_picture_height*3);//,MEM_COMMIT, PAGE_EXECUTE_READWRITE); 
	// dc prediction border 
	
#ifdef _WIN32_WCE
	CacheSync(1);			//Flush cache
#endif
	
	for (i = 0; i < MB_X_Size*2; i++)
		coeff_pred.dc_lum[i][0] = 1024;
	for (i = 1; i < MB_X_Size*2; i++)
		coeff_pred.dc_lum[0][i&3] = 1024;
	for (i = 0; i < MB_X_Size; i++) {
		coeff_pred.dc_chr[0][i][0] = 1024;
		coeff_pred.dc_chr[1][i][0] = 1024;
	}
	for (i = 1; i < MB_X_Size; i++) {
		coeff_pred.dc_chr[0][0][i&1] = 1024;
		coeff_pred.dc_chr[1][0][i&1] = 1024;
	}

	size_lum = mp4_hdr.coded_picture_width * mp4_hdr.coded_picture_height;
	size_crom = mp4_hdr.coded_picture_width * mp4_hdr.coded_picture_height>>2;
	frame_ref[0] = (unsigned char *) (((unsigned char*)BigBuff) + (mp4_hdr.coded_picture_width<<5) + 32);
	BigBuff+= size_lum;
	frame_ref[1] = (unsigned char *) (BigBuff + (mp4_hdr.coded_picture_width<<3) + 16);
	BigBuff+= size_crom;
	frame_ref[2] = (unsigned char *) (BigBuff + (mp4_hdr.coded_picture_width<<3) + 16);
	BigBuff+= size_crom;
	frame_for[0] = (unsigned char *) (((unsigned char*)BigBuff)+ (mp4_hdr.coded_picture_width<<5) + 32);
	BigBuff+= size_lum;
	frame_for[1] = (unsigned char *) (BigBuff + (mp4_hdr.coded_picture_width<<3) + 16);
	BigBuff+= size_crom;
	frame_for[2] = (unsigned char *) (BigBuff + (mp4_hdr.coded_picture_width<<3) + 16);

}

/**/

void closedecoder ()
{
free(tempBB);
}
